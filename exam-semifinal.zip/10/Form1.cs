﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static bool Palindrom(string str2)
        {
            for (int i = 0; i < str2.Length / 2; i++)

                if (str2[i] != str2[str2.Length - i - 1])
                    return false;
            return true;
        }


        private void button1_Click(object sender, EventArgs e)
        {

            string str = richTextBox1.Text;
            string str2 = richTextBox1.Text;
            List<string> listTest = str2.Split(' ').ToList();
            foreach (string obj in listTest)
            {
                if (Palindrom(obj) == true)
                {
                    listBox2.Items.Add(obj);

                }
            }
        }
    }
}
