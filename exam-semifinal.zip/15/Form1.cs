﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private readonly Random _random = new Random();

        private void Form1_Load(object sender, EventArgs e)
        {
        }



        private void button1_Click(object sender, EventArgs e)
        {

            Button btn = new Button();
            btn.Click += new EventHandler(this.button1_Click);
            int x = _random.Next(ClientSize.Width);
            int y = _random.Next(ClientSize.Height);
            int i = 2;
            int counter = i++;
            btn.Text = counter.ToString();
            this.Controls.Add(btn);
            btn.Location = new Point(x, y);

        }
    }
}
