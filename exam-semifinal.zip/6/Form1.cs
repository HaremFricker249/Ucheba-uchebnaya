﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool isPerfectSquare(double x)
        {
            if (x >= 0)
            {

                double sr = Math.Sqrt(x);
                return (sr * sr == x);                // if product of square root is equal, then return T/F
            }
            return false; // else return false if n<0
        }
            private void button1_Click(object sender, EventArgs e)
        {
            double x = int.Parse(textBox1.Text);
            textBox2.Text = isPerfectSquare(x).ToString();
        }
    }
}
