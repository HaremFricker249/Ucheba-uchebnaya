﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static IEnumerable<string> SortByLength(IEnumerable<string> e)
        {
            // Use LINQ to sort the array received and return a copy.
            var sorted = from element in e
            orderby element.Length ascending
            select element;
            return sorted;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string words = textBox1.Text;
            List<string> ListWords = words.Split(' ').ToList();
            foreach (string element in SortByLength(ListWords)) 
            {
                listBox1.Items.Add(element);
                //richTextBox1.Text = "\n" + element;
            }

        }
    }
}
