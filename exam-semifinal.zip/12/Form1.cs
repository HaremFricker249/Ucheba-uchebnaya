﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string text = richTextBox1.Text;
            //char[] charArr = text.ToCharArray();
            int[] count = new int[1200];
            int i;
            for (i = 0; i < text.Length; i++)
                if (text[i] != ' ')
                    count[(int)text[i]]++;
            int n = i;
            
            for (i = 0; i < n; i++)
                if (count[(int)text[i]] == 1)

                    listBox1.Items.Add(text[i]);

            /*foreach (char ch in charArr) 
            {
                int count = text.Split(ch).Length - 1;
                string count_str = Convert.ToString(count);
                string chAndCount = ch + " — " + count_str; 
                listBox1.Items.Add(chAndCount);
                    
            };*/
        }
    }
}
