﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DKR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
        }
        //public enum Figure { Rectangle, Circle, Triangle }
        private readonly Random _random = new Random();
        private readonly Random _random2 = new Random();




        private void Form1_MouseClick_1(object sender, MouseEventArgs e)
        {
            int min = 1;
            int max = 4;
            int minFigure = 25;
            int maxFigure = 250;
            int rndmNum = _random.Next(min, max);
            int rndmNum2 = _random2.Next(minFigure, maxFigure);


            //Figure f = (Figure)(new Random()).Next(0, 3);
            int xValue = e.X;
            int yValue = e.Y;
            

            int caseSwitch = rndmNum;
                switch (caseSwitch)
                {
                    case 1:
                        Graphics rectangle = CreateGraphics();
                        rectangle.DrawRectangle(Pens.Red, e.X, e.Y, rndmNum2, rndmNum2);
                    break;
                    case 2:
                        Graphics ellipse = CreateGraphics();
                        ellipse.DrawEllipse(Pens.Red, e.X, e.Y, rndmNum2, rndmNum2);
                    break;
                    case 3:
                    Graphics triangle = CreateGraphics();

                    Point point1 = new Point(e.X, e.Y);
                    Point point2 = new Point(e.X + rndmNum2, e.Y + rndmNum2);
                    Point point3 = new Point(point2.X + rndmNum2, point2.Y + rndmNum2);
                    Point point4 = new Point(e.X, point3.Y);
                    Point[] curvePoints =
                        {
                            point1,
                            point2,
                            point3,
                            point4
                        };
                    triangle.DrawPolygon(Pens.Red, curvePoints);
                    break;

                }
        }




    }
}
