﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
        bool CheckIsPrime(double number)
        {//there are better ways but this is cheap and easy for an example

            bool result = true;//assume we are prime until we can prove otherwise

            for (double d = 2; d < number; d++)
            {
                if (number % d == 0)
                {
                    result = false;
                    break;
                }
            }

            return result;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            double testthis = 0;
            if (double.TryParse(textBox1.Text, out testthis))
            {
                if (CheckIsPrime(testthis))
                {
                    textBox2.Text = "Число является простым";
                }
                else 
                { 
                    textBox2.Text = "Число не является простым";
                }
            }


        }


    }
}
