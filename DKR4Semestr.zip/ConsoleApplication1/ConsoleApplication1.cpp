#include <iostream>
#include <cmath>
using namespace std;

double f(double x)
{
    double ret = 2 - 5 * x + x * x * x;
    return ret;
}

int main()
{
    long nIter = 1;
    double a, b, e, xmax;
    cout << "Enter a : "; cin >> a;
    cout << "Enter b : "; cin >> b;
    cout << "Enter e : "; cin >> e;
    double t = (sqrt(5) - 1) * 0.5;
    double x1 = b - t * (b - a);
    double x2 = a + t * (b - a);
    while (fabs(b - a)> e)
    {
        cout << "Iteration : " << (nIter++) << endl;
        cout << "a =  " << a << endl;
        cout << "b =  " << b << endl;
        cout << "b-a =  " << b - a << endl;
        cout << "x1 =  " << x1 << endl;
        cout << "x2 =  " << x2 << endl;
        cout << "f(x1) " << f(x1) << endl;
        cout << "f(x2) " << f(x2) << endl << endl;
        if (f(x1) <= f(x2))
            a = x1;
        else
            b = x2;
        x1 = b - t * (b - a);
        x2 = a + t * (b - a);
    }
    cout << "xmax =  " << (xmax = (a + b) * 0.5) << endl << endl;
    cout << "f(xmax) " << f(xmax) << endl << endl;
    system("pause");
    return 0;
}